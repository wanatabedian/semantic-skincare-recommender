<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AdminSeeder extends Seeder
{
    public function run()
    {
        User::create([
            'name'     => 'Admin GlowSemantics',
            'email'    => 'admin@glowsemantics.com',
            'password' => Hash::make('admin123'), // Password default
        ]);
    }
}